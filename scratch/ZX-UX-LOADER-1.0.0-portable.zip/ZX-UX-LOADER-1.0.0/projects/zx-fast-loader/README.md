# ZX-UX Spectrum 48K loader

This folder is a self-contained, reproducible build of the current ZX-UX 48K TZX loader.

## Current known-good contract

- BASIC tape name: `ZX-UX Unix`
- BASIC keeps its initial black-screen `CLS`, but the later/final BASIC `CLS` is removed
- turbo screen initialization clears the full 6144-byte bitmap and sets all 768 attributes white-on-black
- row 21, columns 28-31 retain Spectrum PAPER colors red/yellow/green/cyan during turbo loading
- display text: exactly 24 rows × 32 characters from `text-lines.txt`
- payload range: `0xE000-0xFFFF`
- payload entry point: `0xE003`
- startup beep: exactly one ROM BEEPER call targeting 896 Hz for 250 ms
  (`DE=224`, `HL=458`; integer ROM timing is approximately 896.29 Hz / 249.92 ms)
- rebuilt TZX SHA-256:
  `9a77617b16d04c767c5895261ca9a823b57060e642adadffa58b34cbfcd7d642`

The immutable seed is the loader tagged `ZX-UX-LOADER-WHITE-ON-BLACK-OK`.
Its TZX is stored in portable base64 form at:

`input/known-good-white-on-black-e003.tzx.b64`

Seed SHA-256:

`7ffe2f90b58e87a19a090ca0e0f1323605754af7d8809f3f051662f9faaec6f1`

The seed preserves the exact turbo encoding, payload bytes, timings, lower-screen behavior, and final `0xE003` dispatch. The current builder updates the BASIC-resident 24×32 display array, removes only the seed's final BASIC `CLS`, and installs the machine-code display/beep hook assembled from `src/print_hook.asm`.

## Rebuild

Pinned reference build tools:

- Python 3.12.3
- Pasmo 0.5.3-7

The exact reference environment, package versions, immutable GitHub Action SHAs, Ubuntu package/source locations, and upstream tool sources are recorded in `toolchain.lock.json`. Only Python and Pasmo are required to construct the TZX; Fuse/libspectrum/ROM/X11 packages are validation-only.

From the repository root:

```sh
python3 projects/zx-fast-loader/build.py
```

The build writes:

- `output/zx24_loader_idle_demo.tzx`
- `output/print_hook.bin`
- `output/dummy_e000_8k_idle.bin`
- `output/SHA256SUMS`

The last filename is retained for compatibility with older project tooling. Its contents are the exact current 8 KiB payload extracted from the immutable seed; it is not synthesized by an obsolete idle-program source.

A correct rebuild prints the expected hashes and refuses to complete if the seed, BASIC layout, hook size, text address, turbo tail, payload, final `0xE003` dispatch, or final TZX hash differs.

## Source layout

- `build.py` — deterministic builder and structural validation
- `text-lines.txt` — exactly 24 padded 32-character display rows
- `src/print_hook.asm` — turbo screen reset, four color cells, display hook, and startup beep
- `input/known-good-white-on-black-e003.tzx.b64` — immutable tagged seed
- `rebuild-contract.json` — machine-readable hashes and fixed addresses
- `toolchain.lock.json` — pinned CI/toolchain provenance
- `output/` — checked-in generated artifacts

The previously present `src/idle.asm` was from an older experimental payload generator and is intentionally no longer part of this build. Keeping stale source beside a binary is how tiny computers acquire large mysteries.

## CI sanity checks

The GitHub Actions workflow rebuilds from the folder contents, checks `SHA256SUMS`, compares every regenerated artifact byte-for-byte with the checked-in copies, validates the exact TZX and payload hashes, then loads the rebuilt TZX in Fuse in real time and confirms execution reaches `0xE003`. Tape traps and loader auto-detection are disabled so the ROM loader and custom turbo loader share one continuous tape stream.

That means copying this folder to another checkout with Python and Pasmo available is sufficient to reproduce this exact TZX version.
